/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.ClientDesc;

public class ClientDescImpl implements ClientDesc, ShutdownDestructible {
	protected long m_nativeObject;

	public ClientDescImpl() {
		this(SkypeFactory.getInstance() );
	}

	public ClientDescImpl(ObjectInterfaceFactory factory) {
		m_nativeObject = factory.createClientDesc();
		ShutdownManager.getInstance().addDestructibleObject(factory, this);
	}

	static class ClientDescWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		ClientDescWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroyClientDesc(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new ClientDescWeakRef(factory, this, queue, m_nativeObject);
	}

}

