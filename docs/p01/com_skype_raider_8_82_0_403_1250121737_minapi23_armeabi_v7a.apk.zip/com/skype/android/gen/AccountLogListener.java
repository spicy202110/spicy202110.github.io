/** 
 * (c) 2017 Skype
 * AUTOMATICALLY GENERATED CODE - DO NOT EDIT
 * Feb 27, 2022 1:26:53 PM
 */
package com.skype.android.gen;
public class AccountLogListener implements com.skype.Account.AccountIListener, com.skype.ObjectInterface.ObjectInterfaceIListener {
  public void onSkypeTokenRequired(  com.skype.Account sender,  String invalidToken){
    android.util.Log.d("AccountLogListener","onSkypeTokenRequired");
  }
  public void onTokenRequired(  com.skype.Account sender,  String factorsJson,  String requestMetadataJson,  int tokenTypeAsBitmask,  String invalidToken){
    android.util.Log.d("AccountLogListener","onTokenRequired");
  }
  public void onPropertyChange(  com.skype.ObjectInterface sender,  com.skype.PROPKEY propKey){
    android.util.Log.d("AccountLogListener","onPropertyChange");
  }
}
