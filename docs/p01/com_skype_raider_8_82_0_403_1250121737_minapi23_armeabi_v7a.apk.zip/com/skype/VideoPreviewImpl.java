/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.VideoPreview;

public class VideoPreviewImpl extends ObjectInterfaceImpl implements VideoPreview, ObjectInterface, NativeListenable {
	public VideoPreviewImpl() {
		this(SkypeFactory.getInstance() );
	}

	public VideoPreviewImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createVideoPreview());
		factory.initializeListener(this);
	}

	static class VideoPreviewWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		VideoPreviewWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroyVideoPreview(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new VideoPreviewWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<VideoPreviewIListener> m_listeners = new HashSet<VideoPreviewIListener>();

	@Override
	public void addListener(VideoPreviewIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(VideoPreviewIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	public void onDispose() {
		synchronized (m_listeners) {
			for (VideoPreviewIListener listener : m_listeners) {
				listener.onDispose(this);
			}
		}
	}

	public void onError(VideoPreview.FAILUREREASON error) {
		synchronized (m_listeners) {
			for (VideoPreviewIListener listener : m_listeners) {
				listener.onError(this, error);
			}
		}
	}

	@Override
	public native void attach();

	@Override
	public native void dispose();

	public native void createBinding(int type, long binding);
	public native void releaseBinding(int type, long binding);
}

