/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.UpdateMeetingLiveStateParameters;

public class UpdateMeetingLiveStateParametersImpl extends InMemoryObjectImpl implements UpdateMeetingLiveStateParameters, NativeListenable {
	public UpdateMeetingLiveStateParametersImpl() {
		this(SkypeFactory.getInstance() );
	}

	public UpdateMeetingLiveStateParametersImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createUpdateMeetingLiveStateParameters());
		factory.initializeListener(this);
	}

	static class UpdateMeetingLiveStateParametersWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		UpdateMeetingLiveStateParametersWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroyUpdateMeetingLiveStateParameters(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new UpdateMeetingLiveStateParametersWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<UpdateMeetingLiveStateParametersIListener> m_listeners = new HashSet<UpdateMeetingLiveStateParametersIListener>();

	@Override
	public void addListener(UpdateMeetingLiveStateParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(UpdateMeetingLiveStateParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	@Override
	public native SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	@Override
	public native int getObjectID();

	@Override
	public void setPhase(String phase) {
		setPhase(NativeStringConvert.ConvertToNativeBytes(phase));
	}

	private native void setPhase(byte[] phase);
}

