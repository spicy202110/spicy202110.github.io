/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.SkCompositor;

public class SkCompositorImpl extends ObjectInterfaceImpl implements SkCompositor, ObjectInterface, NativeListenable {
	public SkCompositorImpl() {
		this(SkypeFactory.getInstance() );
	}

	public SkCompositorImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createSkCompositor());
		factory.initializeListener(this);
	}

	static class SkCompositorWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		SkCompositorWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroySkCompositor(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new SkCompositorWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<SkCompositorIListener> m_listeners = new HashSet<SkCompositorIListener>();

	@Override
	public void addListener(SkCompositorIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(SkCompositorIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	public void onCompositorError(byte[] error) {
		synchronized (m_listeners) {
			for (SkCompositorIListener listener : m_listeners) {
				listener.onCompositorError(this, NativeStringConvert.ConvertFromNativeBytes(error));
			}
		}
	}

	public void onDispose() {
		synchronized (m_listeners) {
			for (SkCompositorIListener listener : m_listeners) {
				listener.onDispose(this);
			}
		}
	}

	public void onLayoutUpdate(byte[] layout) {
		synchronized (m_listeners) {
			for (SkCompositorIListener listener : m_listeners) {
				listener.onLayoutUpdate(this, NativeStringConvert.ConvertFromNativeBytes(layout));
			}
		}
	}

	@Override
	public native void addVideoView(int viewId, int videoObjectID);

	@Override
	public native void dispose();

	@Override
	public native void removeVideoView(int viewId);

	@Override
	public native void start();

	@Override
	public native void stop();

	@Override
	public boolean updateLayout(String layout) {
		return updateLayout(NativeStringConvert.ConvertToNativeBytes(layout));
	}

	private native boolean updateLayout(byte[] layout);
	public native void createBinding(int type, long binding);
	public native void releaseBinding(int type, long binding);
}

