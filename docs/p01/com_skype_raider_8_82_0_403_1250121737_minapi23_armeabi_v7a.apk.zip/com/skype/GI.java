/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

public interface GI {
	public enum LIBSTATUS {
		CONSTRUCTED(0),
		STARTING(1),
		RUNNING(2),
		STOPPING(3),
		STOPPED(4),
		FATAL_ERROR(5),
		WRAPPER_UNKNOWN_VALUE(Integer.MAX_VALUE);
		
		private final int value;
		
		LIBSTATUS(int value) {
			this.value = value;
		}

		public int toInt() {
			return value;
		}

		private static final SparseArrayCompat<LIBSTATUS> intToTypeMap = new SparseArrayCompat< LIBSTATUS>();
		
		static {
			for (LIBSTATUS type : LIBSTATUS.values()) {
				intToTypeMap.put(type.value, type);
			}
		}

		public static LIBSTATUS fromInt(int i) {
			LIBSTATUS tmpVar = intToTypeMap.get(i);
			return (tmpVar != null) ? tmpVar : LIBSTATUS.WRAPPER_UNKNOWN_VALUE;
		}
	}

	public enum NETWORKACTIVITYLEVEL {
		NAL_NORMAL_LEVEL(3),
		NAL_FIRST_QUIET_LEVEL(7),
		NAL_QUIET_WITH_NETWORK_LEVEL(7),
		NAL_QUIET_SUSPENDED_LEVEL(8),
		NAL_QUIET_SUSPENDED_OFFLINE_LEVEL(9),
		NAL_LAST_LEVEL_DONT_USE(10),
		WRAPPER_UNKNOWN_VALUE(Integer.MAX_VALUE);
		
		private final int value;
		
		NETWORKACTIVITYLEVEL(int value) {
			this.value = value;
		}

		public int toInt() {
			return value;
		}

		private static final SparseArrayCompat<NETWORKACTIVITYLEVEL> intToTypeMap = new SparseArrayCompat< NETWORKACTIVITYLEVEL>();
		
		static {
			for (NETWORKACTIVITYLEVEL type : NETWORKACTIVITYLEVEL.values()) {
				intToTypeMap.put(type.value, type);
			}
		}

		public static NETWORKACTIVITYLEVEL fromInt(int i) {
			NETWORKACTIVITYLEVEL tmpVar = intToTypeMap.get(i);
			return (tmpVar != null) ? tmpVar : NETWORKACTIVITYLEVEL.WRAPPER_UNKNOWN_VALUE;
		}
	}

	public interface GIIListener {
		void onLibStatusChange(GI sender, GI.LIBSTATUS newStatus);
	}

	public void addListener(GIIListener listener);

	public void removeListener(GIIListener listener);

	
	public String getActiveLogFileName();

	public GI.LIBSTATUS getLibStatus();

	public Setup getSetup();

	public Setup getSetup(String profile);

	public void pollEvents(int waitMs);

	public void pollEvents();

	public void updateLogName();

}

