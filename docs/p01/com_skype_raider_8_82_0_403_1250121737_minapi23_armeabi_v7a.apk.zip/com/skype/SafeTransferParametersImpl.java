/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.SafeTransferParameters;

public class SafeTransferParametersImpl extends InMemoryObjectImpl implements SafeTransferParameters, NativeListenable {
	public SafeTransferParametersImpl() {
		this(SkypeFactory.getInstance() );
	}

	public SafeTransferParametersImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createSafeTransferParameters());
		factory.initializeListener(this);
	}

	static class SafeTransferParametersWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		SafeTransferParametersWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroySafeTransferParameters(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new SafeTransferParametersWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<SafeTransferParametersIListener> m_listeners = new HashSet<SafeTransferParametersIListener>();

	@Override
	public void addListener(SafeTransferParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(SafeTransferParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	@Override
	public native SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	@Override
	public native int getObjectID();

	@Override
	public void setClientTransferContextJson(String clientTransferContextJson) {
		setClientTransferContextJson(NativeStringConvert.ConvertToNativeBytes(clientTransferContextJson));
	}

	private native void setClientTransferContextJson(byte[] clientTransferContextJson);
	@Override
	public native void setDisableForwardingAndUnanswered(boolean disableForwardingAndUnanswered);

}

