/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

public interface Video extends ObjectInterface {
	public enum STATUS {
		NOT_AVAILABLE(0),
		AVAILABLE(1),
		STARTING(2),
		RUNNING(4),
		STOPPING(5),
		PAUSED(6),
		NOT_STARTED(7),
		UNKNOWN(9),
		WRAPPER_UNKNOWN_VALUE(Integer.MAX_VALUE);
		
		private final int value;
		
		STATUS(int value) {
			this.value = value;
		}

		public int toInt() {
			return value;
		}

		private static final SparseArrayCompat<STATUS> intToTypeMap = new SparseArrayCompat< STATUS>();
		
		static {
			for (STATUS type : STATUS.values()) {
				intToTypeMap.put(type.value, type);
			}
		}

		public static STATUS fromInt(int i) {
			STATUS tmpVar = intToTypeMap.get(i);
			return (tmpVar != null) ? tmpVar : STATUS.WRAPPER_UNKNOWN_VALUE;
		}
	}

	public enum MEDIATYPE {
		MEDIA_SCREENSHARING(1),
		MEDIA_VIDEO(0),
		MEDIA_SR_AUGMENTED(2),
		WRAPPER_UNKNOWN_VALUE(Integer.MAX_VALUE);
		
		private final int value;
		
		MEDIATYPE(int value) {
			this.value = value;
		}

		public int toInt() {
			return value;
		}

		private static final SparseArrayCompat<MEDIATYPE> intToTypeMap = new SparseArrayCompat< MEDIATYPE>();
		
		static {
			for (MEDIATYPE type : MEDIATYPE.values()) {
				intToTypeMap.put(type.value, type);
			}
		}

		public static MEDIATYPE fromInt(int i) {
			MEDIATYPE tmpVar = intToTypeMap.get(i);
			return (tmpVar != null) ? tmpVar : MEDIATYPE.WRAPPER_UNKNOWN_VALUE;
		}
	}

	public STATUS getStatusProp();

	public String getErrorProp();

	public MEDIATYPE getMediaTypeProp();

	public String getLabelProp();

	public int getConvoIdProp();

	public String getDevicePathProp();

	public String getDeviceNameProp();

	public int getParticipantIdProp();

	public int getRankProp();

	public String getEndpointIdProp();

	public String getParticipantLegIdProp();

	public String getParticipantMriProp();

	public String getNegotiationTagProp();

	public int getVirtualParticipantMsiProp();

	public interface VideoIListener {
	}

	public void addListener(VideoIListener listener);

	public void removeListener(VideoIListener listener);

	
	public void setScreenCaptureRectangle(int x0, int y0, int width, int height, int monitorNumber, int windowHandle);

	public void setScreenCaptureRectangle(int x0, int y0, int width, int height);

	public void setScreenCaptureRectangle(int x0, int y0, int width, int height, int monitorNumber);

	public void start(String negotiationTag);

	public void start();

	public void stop(String negotiationTag);

	public void stop();

}

