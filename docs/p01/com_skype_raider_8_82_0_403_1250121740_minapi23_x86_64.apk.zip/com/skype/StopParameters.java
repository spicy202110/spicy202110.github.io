/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

public interface StopParameters {
	public interface StopParametersIListener {
	}

	public void addListener(StopParametersIListener listener);

	public void removeListener(StopParametersIListener listener);

	
	public SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	public int getObjectID();

	public void setCauseId(String causeId);

	public void setEndpointScope(CallHandler.ENDPOINT_SCOPE endpointScope);

	public void setReasonPhrase(String clientPhrase);

	public void setReasonSubCode(int clientSubCode);

}

