/** 
 * (c) 2017 Skype
 * AUTOMATICALLY GENERATED CODE - DO NOT EDIT
 * Feb 27, 2022 1:26:53 PM
 */
package com.skype.android.gen;
public class RemoteControlSessionListener implements com.skype.RemoteControlSession.RemoteControlSessionIListener, com.skype.ObjectInterface.ObjectInterfaceIListener {
  final com.skype.android.event.EventBus eventBus=com.skype.android.event.EventBusInstance.get();
public static class OnControlSessionStatusChanged {
    private com.skype.RemoteControlSession _sender;
    private com.skype.RemoteControlSession.STATUS _status;
    private com.skype.RemoteControlSession.REASON _reason;
    public OnControlSessionStatusChanged(    com.skype.RemoteControlSession sender,    com.skype.RemoteControlSession.STATUS status,    com.skype.RemoteControlSession.REASON reason){
      _sender=sender;
      _status=status;
      _reason=reason;
    }
    public com.skype.RemoteControlSession getSender(){
      return _sender;
    }
    public com.skype.RemoteControlSession.STATUS getStatus(){
      return _status;
    }
    public com.skype.RemoteControlSession.REASON getReason(){
      return _reason;
    }
  }
  public void onControlSessionStatusChanged(  com.skype.RemoteControlSession sender,  com.skype.RemoteControlSession.STATUS status,  com.skype.RemoteControlSession.REASON reason){
    try {
      OnControlSessionStatusChanged event=new OnControlSessionStatusChanged(sender,status,reason);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnIncomingControlRequestCancelled {
    private com.skype.RemoteControlSession _sender;
    private String _participantId;
    public OnIncomingControlRequestCancelled(    com.skype.RemoteControlSession sender,    String participantId){
      _sender=sender;
      _participantId=participantId;
    }
    public com.skype.RemoteControlSession getSender(){
      return _sender;
    }
    public String getParticipantId(){
      return _participantId;
    }
  }
  public void onIncomingControlRequestCancelled(  com.skype.RemoteControlSession sender,  String participantId){
    try {
      OnIncomingControlRequestCancelled event=new OnIncomingControlRequestCancelled(sender,participantId);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnIncomingControlRequest {
    private com.skype.RemoteControlSession _sender;
    private String _participantId;
    public OnIncomingControlRequest(    com.skype.RemoteControlSession sender,    String participantId){
      _sender=sender;
      _participantId=participantId;
    }
    public com.skype.RemoteControlSession getSender(){
      return _sender;
    }
    public String getParticipantId(){
      return _participantId;
    }
  }
  public void onIncomingControlRequest(  com.skype.RemoteControlSession sender,  String participantId){
    try {
      OnIncomingControlRequest event=new OnIncomingControlRequest(sender,participantId);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnPTZDeviceControlCommand {
    private com.skype.RemoteControlSession _sender;
    private int _ptzCommand;
    public OnPTZDeviceControlCommand(    com.skype.RemoteControlSession sender,    int ptzCommand){
      _sender=sender;
      _ptzCommand=ptzCommand;
    }
    public com.skype.RemoteControlSession getSender(){
      return _sender;
    }
    public int getPtzCommand(){
      return _ptzCommand;
    }
  }
  public void onPTZDeviceControlCommand(  com.skype.RemoteControlSession sender,  int ptzCommand){
    try {
      OnPTZDeviceControlCommand event=new OnPTZDeviceControlCommand(sender,ptzCommand);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnRemotePTZDeviceStateChanged {
    private com.skype.RemoteControlSession _sender;
    private int _remotePTZDeviceState;
    public OnRemotePTZDeviceStateChanged(    com.skype.RemoteControlSession sender,    int remotePTZDeviceState){
      _sender=sender;
      _remotePTZDeviceState=remotePTZDeviceState;
    }
    public com.skype.RemoteControlSession getSender(){
      return _sender;
    }
    public int getRemotePTZDeviceState(){
      return _remotePTZDeviceState;
    }
  }
  public void onRemotePTZDeviceStateChanged(  com.skype.RemoteControlSession sender,  int remotePTZDeviceState){
    try {
      OnRemotePTZDeviceStateChanged event=new OnRemotePTZDeviceStateChanged(sender,remotePTZDeviceState);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnPropertyChange {
    private com.skype.ObjectInterface _sender;
    private com.skype.PROPKEY _propKey;
    public OnPropertyChange(    com.skype.ObjectInterface sender,    com.skype.PROPKEY propKey){
      _sender=sender;
      _propKey=propKey;
    }
    public com.skype.ObjectInterface getSender(){
      return _sender;
    }
    public com.skype.PROPKEY getPropKey(){
      return _propKey;
    }
  }
  public void onPropertyChange(  com.skype.ObjectInterface sender,  com.skype.PROPKEY propKey){
    try {
      OnPropertyChange event=new OnPropertyChange(sender,propKey);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(propKey,t));
    }
  }
}
