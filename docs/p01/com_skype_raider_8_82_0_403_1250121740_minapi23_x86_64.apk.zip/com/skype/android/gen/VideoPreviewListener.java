/** 
 * (c) 2017 Skype
 * AUTOMATICALLY GENERATED CODE - DO NOT EDIT
 * Feb 27, 2022 1:26:53 PM
 */
package com.skype.android.gen;
public class VideoPreviewListener implements com.skype.VideoPreview.VideoPreviewIListener, com.skype.ObjectInterface.ObjectInterfaceIListener {
  final com.skype.android.event.EventBus eventBus=com.skype.android.event.EventBusInstance.get();
public static class OnDispose {
    private com.skype.VideoPreview _sender;
    public OnDispose(    com.skype.VideoPreview sender){
      _sender=sender;
    }
    public com.skype.VideoPreview getSender(){
      return _sender;
    }
  }
  public void onDispose(  com.skype.VideoPreview sender){
    try {
      OnDispose event=new OnDispose(sender);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnError {
    private com.skype.VideoPreview _sender;
    private com.skype.VideoPreview.FAILUREREASON _error;
    public OnError(    com.skype.VideoPreview sender,    com.skype.VideoPreview.FAILUREREASON error){
      _sender=sender;
      _error=error;
    }
    public com.skype.VideoPreview getSender(){
      return _sender;
    }
    public com.skype.VideoPreview.FAILUREREASON getError(){
      return _error;
    }
  }
  public void onError(  com.skype.VideoPreview sender,  com.skype.VideoPreview.FAILUREREASON error){
    try {
      OnError event=new OnError(sender,error);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnPropertyChange {
    private com.skype.ObjectInterface _sender;
    private com.skype.PROPKEY _propKey;
    public OnPropertyChange(    com.skype.ObjectInterface sender,    com.skype.PROPKEY propKey){
      _sender=sender;
      _propKey=propKey;
    }
    public com.skype.ObjectInterface getSender(){
      return _sender;
    }
    public com.skype.PROPKEY getPropKey(){
      return _propKey;
    }
  }
  public void onPropertyChange(  com.skype.ObjectInterface sender,  com.skype.PROPKEY propKey){
    try {
      OnPropertyChange event=new OnPropertyChange(sender,propKey);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(propKey,t));
    }
  }
}
