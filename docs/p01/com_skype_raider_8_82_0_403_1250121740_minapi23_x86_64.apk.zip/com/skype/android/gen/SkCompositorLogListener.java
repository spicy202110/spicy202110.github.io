/** 
 * (c) 2017 Skype
 * AUTOMATICALLY GENERATED CODE - DO NOT EDIT
 * Feb 27, 2022 1:26:53 PM
 */
package com.skype.android.gen;
public class SkCompositorLogListener implements com.skype.SkCompositor.SkCompositorIListener, com.skype.ObjectInterface.ObjectInterfaceIListener {
  public void onCompositorError(  com.skype.SkCompositor sender,  String error){
    android.util.Log.d("SkCompositorLogListener","onCompositorError");
  }
  public void onDispose(  com.skype.SkCompositor sender){
    android.util.Log.d("SkCompositorLogListener","onDispose");
  }
  public void onLayoutUpdate(  com.skype.SkCompositor sender,  String layout){
    android.util.Log.d("SkCompositorLogListener","onLayoutUpdate");
  }
  public void onPropertyChange(  com.skype.ObjectInterface sender,  com.skype.PROPKEY propKey){
    android.util.Log.d("SkCompositorLogListener","onPropertyChange");
  }
}
