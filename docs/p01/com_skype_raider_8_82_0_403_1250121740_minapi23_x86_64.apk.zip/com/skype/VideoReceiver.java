/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

public interface VideoReceiver extends ObjectInterface {
	public enum STATUS {
		STOPPED(0),
		STARTED(1),
		ACTIVE(2),
		INACTIVE(3),
		TERMINATED(5),
		WRAPPER_UNKNOWN_VALUE(Integer.MAX_VALUE);
		
		private final int value;
		
		STATUS(int value) {
			this.value = value;
		}

		public int toInt() {
			return value;
		}

		private static final SparseArrayCompat<STATUS> intToTypeMap = new SparseArrayCompat< STATUS>();
		
		static {
			for (STATUS type : STATUS.values()) {
				intToTypeMap.put(type.value, type);
			}
		}

		public static STATUS fromInt(int i) {
			STATUS tmpVar = intToTypeMap.get(i);
			return (tmpVar != null) ? tmpVar : STATUS.WRAPPER_UNKNOWN_VALUE;
		}
	}

	public enum FAILUREREASON {
		NOFAILURE(0),
		CAN_NOT_START(2),
		CAN_NOT_SUBSCRIBE(5),
		WRAPPER_UNKNOWN_VALUE(Integer.MAX_VALUE);
		
		private final int value;
		
		FAILUREREASON(int value) {
			this.value = value;
		}

		public int toInt() {
			return value;
		}

		private static final SparseArrayCompat<FAILUREREASON> intToTypeMap = new SparseArrayCompat< FAILUREREASON>();
		
		static {
			for (FAILUREREASON type : FAILUREREASON.values()) {
				intToTypeMap.put(type.value, type);
			}
		}

		public static FAILUREREASON fromInt(int i) {
			FAILUREREASON tmpVar = intToTypeMap.get(i);
			return (tmpVar != null) ? tmpVar : FAILUREREASON.WRAPPER_UNKNOWN_VALUE;
		}
	}

	public interface VideoReceiverIListener {
		void onChannelLost(VideoReceiver sender);
		void onDispose(VideoReceiver sender);
		void onError(VideoReceiver sender, VideoReceiver.FAILUREREASON error);
		void onStatus(VideoReceiver sender, VideoReceiver.STATUS status);
		void onSubscription(VideoReceiver sender, int videoObjectId);
		void onVirtualParticipant(VideoReceiver sender, int virtualParticipantSourceId);
	}

	public void addListener(VideoReceiverIListener listener);

	public void removeListener(VideoReceiverIListener listener);

	
	public void dispose();

	public void subscribe(int videoObjectId);

}

