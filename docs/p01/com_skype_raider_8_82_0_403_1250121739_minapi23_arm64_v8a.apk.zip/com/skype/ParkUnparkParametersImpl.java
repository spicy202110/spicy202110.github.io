/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.ParkUnparkParameters;

public class ParkUnparkParametersImpl extends InMemoryObjectImpl implements ParkUnparkParameters, NativeListenable {
	public ParkUnparkParametersImpl() {
		this(SkypeFactory.getInstance() );
	}

	public ParkUnparkParametersImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createParkUnparkParameters());
		factory.initializeListener(this);
	}

	static class ParkUnparkParametersWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		ParkUnparkParametersWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroyParkUnparkParameters(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new ParkUnparkParametersWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<ParkUnparkParametersIListener> m_listeners = new HashSet<ParkUnparkParametersIListener>();

	@Override
	public void addListener(ParkUnparkParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(ParkUnparkParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	@Override
	public native SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	@Override
	public native int getObjectID();

	@Override
	public void setCauseId(String causeId) {
		setCauseId(NativeStringConvert.ConvertToNativeBytes(causeId));
	}

	private native void setCauseId(byte[] causeId);
	@Override
	public native void setParkContext(CallHandler.PARK_CONTEXT parkContext);

}

