/* =============================================================================
 *                      GENERATED FILE - DO NOT MODIFY
 * =============================================================================
 * Copyright © Microsoft Corporation. All rights reserved.
 * 
 */
package com.skype;
import android.support.v4.util.SparseArrayCompat;
import java.util.Set;
import java.util.HashSet;
import java.lang.ref.ReferenceQueue;
import com.skype.NativeStringConvert;

import com.skype.SearchOptionsParameters;

public class SearchOptionsParametersImpl extends InMemoryObjectImpl implements SearchOptionsParameters, NativeListenable {
	public SearchOptionsParametersImpl() {
		this(SkypeFactory.getInstance() );
	}

	public SearchOptionsParametersImpl(ObjectInterfaceFactory factory) {
		super(factory,factory.createSearchOptionsParameters());
		factory.initializeListener(this);
	}

	static class SearchOptionsParametersWeakRef extends NativeWeakRef<ShutdownDestructible> {
		private ObjectInterfaceFactory factory;
		SearchOptionsParametersWeakRef(ObjectInterfaceFactory factory, ShutdownDestructible ref, ReferenceQueue<ShutdownDestructible> queue, long nativeObject) {
			super(ref, queue, nativeObject);
			this.factory = factory;
		}
		public void destroyNativeObject() {
			factory.destroySearchOptionsParameters(nativeObject);
		}
	}

	public NativeWeakRef<ShutdownDestructible> createNativeWeakRef(ObjectInterfaceFactory factory, ReferenceQueue<ShutdownDestructible> queue) {
		return new SearchOptionsParametersWeakRef(factory, this, queue, m_nativeObject);
	}

	public native void initializeListener();
	
	private final Set<SearchOptionsParametersIListener> m_listeners = new HashSet<SearchOptionsParametersIListener>();

	@Override
	public void addListener(SearchOptionsParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.add(listener);
		}
	}

	@Override
	public void removeListener(SearchOptionsParametersIListener listener) {
		synchronized (m_listeners) {
			m_listeners.remove(listener);
		}
	}

	@Override
	public native SkyLib.IN_MEMORY_OBJECTTYPE getInMemObjectType();

	@Override
	public native int getObjectID();

	@Override
	public String getSearchOptionsParametersJson() {
		return NativeStringConvert.ConvertFromNativeBytes(getSearchOptionsParametersJsonNativeString());
	}

	private native byte[] getSearchOptionsParametersJsonNativeString();
	@Override
	public native void setLimit(int limit);

	@Override
	public void setMris(String[] mris) {
		setMris(NativeStringConvert.ConvertArrToNativeByteArr(mris));
	}

	private native void setMris(byte[][] mris);
	@Override
	public void setQueryString(String queryString) {
		setQueryString(NativeStringConvert.ConvertToNativeBytes(queryString));
	}

	private native void setQueryString(byte[] queryString);
}

