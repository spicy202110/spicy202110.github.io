/** 
 * (c) 2017 Skype
 * AUTOMATICALLY GENERATED CODE - DO NOT EDIT
 * Feb 27, 2022 1:26:53 PM
 */
package com.skype.android.gen;
public class VideoPreviewLogListener implements com.skype.VideoPreview.VideoPreviewIListener, com.skype.ObjectInterface.ObjectInterfaceIListener {
  public void onDispose(  com.skype.VideoPreview sender){
    android.util.Log.d("VideoPreviewLogListener","onDispose");
  }
  public void onError(  com.skype.VideoPreview sender,  com.skype.VideoPreview.FAILUREREASON error){
    android.util.Log.d("VideoPreviewLogListener","onError");
  }
  public void onPropertyChange(  com.skype.ObjectInterface sender,  com.skype.PROPKEY propKey){
    android.util.Log.d("VideoPreviewLogListener","onPropertyChange");
  }
}
