/** 
 * (c) 2017 Skype
 * AUTOMATICALLY GENERATED CODE - DO NOT EDIT
 * Feb 27, 2022 1:26:53 PM
 */
package com.skype.android.gen;
public class VideoReceiverListener implements com.skype.VideoReceiver.VideoReceiverIListener, com.skype.ObjectInterface.ObjectInterfaceIListener {
  final com.skype.android.event.EventBus eventBus=com.skype.android.event.EventBusInstance.get();
public static class OnChannelLost {
    private com.skype.VideoReceiver _sender;
    public OnChannelLost(    com.skype.VideoReceiver sender){
      _sender=sender;
    }
    public com.skype.VideoReceiver getSender(){
      return _sender;
    }
  }
  public void onChannelLost(  com.skype.VideoReceiver sender){
    try {
      OnChannelLost event=new OnChannelLost(sender);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnDispose {
    private com.skype.VideoReceiver _sender;
    public OnDispose(    com.skype.VideoReceiver sender){
      _sender=sender;
    }
    public com.skype.VideoReceiver getSender(){
      return _sender;
    }
  }
  public void onDispose(  com.skype.VideoReceiver sender){
    try {
      OnDispose event=new OnDispose(sender);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnError {
    private com.skype.VideoReceiver _sender;
    private com.skype.VideoReceiver.FAILUREREASON _error;
    public OnError(    com.skype.VideoReceiver sender,    com.skype.VideoReceiver.FAILUREREASON error){
      _sender=sender;
      _error=error;
    }
    public com.skype.VideoReceiver getSender(){
      return _sender;
    }
    public com.skype.VideoReceiver.FAILUREREASON getError(){
      return _error;
    }
  }
  public void onError(  com.skype.VideoReceiver sender,  com.skype.VideoReceiver.FAILUREREASON error){
    try {
      OnError event=new OnError(sender,error);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnStatus {
    private com.skype.VideoReceiver _sender;
    private com.skype.VideoReceiver.STATUS _status;
    public OnStatus(    com.skype.VideoReceiver sender,    com.skype.VideoReceiver.STATUS status){
      _sender=sender;
      _status=status;
    }
    public com.skype.VideoReceiver getSender(){
      return _sender;
    }
    public com.skype.VideoReceiver.STATUS getStatus(){
      return _status;
    }
  }
  public void onStatus(  com.skype.VideoReceiver sender,  com.skype.VideoReceiver.STATUS status){
    try {
      OnStatus event=new OnStatus(sender,status);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnSubscription {
    private com.skype.VideoReceiver _sender;
    private int _videoObjectId;
    public OnSubscription(    com.skype.VideoReceiver sender,    int videoObjectId){
      _sender=sender;
      _videoObjectId=videoObjectId;
    }
    public com.skype.VideoReceiver getSender(){
      return _sender;
    }
    public int getVideoObjectId(){
      return _videoObjectId;
    }
  }
  public void onSubscription(  com.skype.VideoReceiver sender,  int videoObjectId){
    try {
      OnSubscription event=new OnSubscription(sender,videoObjectId);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnVirtualParticipant {
    private com.skype.VideoReceiver _sender;
    private int _virtualParticipantSourceId;
    public OnVirtualParticipant(    com.skype.VideoReceiver sender,    int virtualParticipantSourceId){
      _sender=sender;
      _virtualParticipantSourceId=virtualParticipantSourceId;
    }
    public com.skype.VideoReceiver getSender(){
      return _sender;
    }
    public int getVirtualParticipantSourceId(){
      return _virtualParticipantSourceId;
    }
  }
  public void onVirtualParticipant(  com.skype.VideoReceiver sender,  int virtualParticipantSourceId){
    try {
      OnVirtualParticipant event=new OnVirtualParticipant(sender,virtualParticipantSourceId);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(t));
    }
  }
public static class OnPropertyChange {
    private com.skype.ObjectInterface _sender;
    private com.skype.PROPKEY _propKey;
    public OnPropertyChange(    com.skype.ObjectInterface sender,    com.skype.PROPKEY propKey){
      _sender=sender;
      _propKey=propKey;
    }
    public com.skype.ObjectInterface getSender(){
      return _sender;
    }
    public com.skype.PROPKEY getPropKey(){
      return _propKey;
    }
  }
  public void onPropertyChange(  com.skype.ObjectInterface sender,  com.skype.PROPKEY propKey){
    try {
      OnPropertyChange event=new OnPropertyChange(sender,propKey);
      eventBus.sendEvent(event);
    }
 catch (    java.lang.Throwable t) {
      com.skype.android.event.ListenerErrorReporter.report(new com.skype.android.event.ListenerError(propKey,t));
    }
  }
}
