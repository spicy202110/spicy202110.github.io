/** 
 * (c) 2017 Skype
 * AUTOMATICALLY GENERATED CODE - DO NOT EDIT
 * Feb 27, 2022 1:26:53 PM
 */
package com.skype.android.gen;
public class RemoteControlSessionLogListener implements com.skype.RemoteControlSession.RemoteControlSessionIListener, com.skype.ObjectInterface.ObjectInterfaceIListener {
  public void onControlSessionStatusChanged(  com.skype.RemoteControlSession sender,  com.skype.RemoteControlSession.STATUS status,  com.skype.RemoteControlSession.REASON reason){
    android.util.Log.d("RemoteControlSessionLogListener","onControlSessionStatusChanged");
  }
  public void onIncomingControlRequestCancelled(  com.skype.RemoteControlSession sender,  String participantId){
    android.util.Log.d("RemoteControlSessionLogListener","onIncomingControlRequestCancelled");
  }
  public void onIncomingControlRequest(  com.skype.RemoteControlSession sender,  String participantId){
    android.util.Log.d("RemoteControlSessionLogListener","onIncomingControlRequest");
  }
  public void onPTZDeviceControlCommand(  com.skype.RemoteControlSession sender,  int ptzCommand){
    android.util.Log.d("RemoteControlSessionLogListener","onPTZDeviceControlCommand");
  }
  public void onRemotePTZDeviceStateChanged(  com.skype.RemoteControlSession sender,  int remotePTZDeviceState){
    android.util.Log.d("RemoteControlSessionLogListener","onRemotePTZDeviceStateChanged");
  }
  public void onPropertyChange(  com.skype.ObjectInterface sender,  com.skype.PROPKEY propKey){
    android.util.Log.d("RemoteControlSessionLogListener","onPropertyChange");
  }
}
