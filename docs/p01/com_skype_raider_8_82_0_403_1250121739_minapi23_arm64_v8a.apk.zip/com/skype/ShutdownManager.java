package com.skype;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.lang.ref.ReferenceQueue;

class ShutdownManager {
    public final ConcurrentLinkedDeque<NativeWeakRef<?>> referencesQueue = new ConcurrentLinkedDeque<NativeWeakRef<?>>();
    private final ReferenceQueue<ShutdownDestructible> queue = new ReferenceQueue<ShutdownDestructible>();

    private Thread thread = new Thread("ShutdownManager") {
        public void run() {
            while (true) {
                NativeWeakRef<? extends ShutdownDestructible> reference;
                try {
                    reference = (NativeWeakRef<? extends ShutdownDestructible>) queue.remove();
                    if (referencesQueue.contains(reference)) {
                        referencesQueue.remove(reference);
                        reference.destroyNativeObject();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
    };

    private ShutdownManager() {
        thread.setPriority(Thread.MIN_PRIORITY);
        thread.setDaemon(true);
        thread.start();
    }

    private static volatile ShutdownManager instance;

    public static ShutdownManager getInstance() {
        if (instance == null) {
            synchronized (ShutdownManager.class) {
                if (instance == null)
                    instance = new ShutdownManager();
            }
        }
        return instance;
    }

/******************************************************************************
    After calling reset, the references are cleaned up.
    The caller should make sure that the references are not used after that.
******************************************************************************/
    public void reset() {
        try {
            while (true) {
                NativeWeakRef<?> reference = referencesQueue.pollLast();
                if (reference == null)
                {
                    break;
                }
                reference.destroyNativeObject();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addDestructibleObject(ObjectInterfaceFactory factory, ShutdownDestructible destructible) {
        referencesQueue.add(destructible.createNativeWeakRef(factory, queue));
    }

}